rgb = imread("C:\Users\14876\Desktop\11.png");%读取原图像
I = rgb2gray (rgb) ; %转化为灰度图像
figure; subplot (121) %显示灰度图像
imshow (I)
text (732, 501, ' Image courtesy of Corel', ...
'FontSize', 7, 'HorizontalAlignment' , ' right')
hy = fspecial('sobel') ;%sobel算子
hx = hy';
Iy = imfilter(double(I),hy,'replicate');%滤波求y方向边缘
Ix = imfilter(double(I),hx,'replicate');%滤波求x方向边缘
gradmag = sqrt(Ix.^2 + Iy.^2);%求模
subplot(122) ; imshow (gradmag, []),%显示梯度
title ('Gradient magnitude (gradmag)')
