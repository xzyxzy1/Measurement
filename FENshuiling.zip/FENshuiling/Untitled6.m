clear,clc

%三种方法进行分水岭分割

%读入图像

filename="C:\Users\14876\Desktop\1.png";

f=imread(filename);

Info=imfinfo(filename);

if Info.BitDepth==8

f=rgb2gray(f);

end

figure,mesh(double(f));%显示图像，类似集水盆地

%方法1：一般分水岭分割，从结果可以看出存在过分割问题

b=im2bw(f,graythresh(f));%二值化,注意应保证集水盆地的值较低（为0），否则就要对b取反

d=bwdist(b); %求零值到最近非零值的距离，即集水盆地到分水岭的距离

l=watershed(-d); %matlab自带分水岭算法，l中的零值即为风水岭

w=l==0; %取出边缘

%g=b~w; %用w作为mask从二值图像中取值

figure

subplot(2,3,1),imshow(f);

subplot(2,3,2),imshow(b);

subplot(2,3,3),imshow(d);

subplot(2,3,4),imshow(l);

subplot(2,3,5),imshow(w);

subplot(2,3,6),imshow(g);