clc;                %clc的作用就是清屏幕
clear;              %clear是删除所有的变量
close all;          %close all是将所有打开的图片关掉。
filename=('8.jpg');        %读入图像
f=imread(filename);
imshow(f);
Info=imfinfo(filename);
if Info.BitDepth>8
   f=rgb2gray(f);
end
figure, mesh(double(f));        %显示图像，类似集水盆地，类似集水盆地
