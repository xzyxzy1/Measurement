I= imread("12.jpg");      
imshow(I);  
h=fspecial('sobel'); %h = fspecial(type) creates a two-dimensional filter h of the specified type. fspecial returns h as  
                     %a correlation kernel, which is the appropriate form to use with imfilter. type is a string having one of these values.   
fd=double(I);%double使数据变成双精度  
g=sqrt(imfilter(fd,h,'replicate').^2+imfilter(fd,h.','replicate').^2);  
figure;  
imshow(g);  
g2=imclose(imopen(g,ones(3,3)),ones(3,3));  
figure;  
imshow(g2);  
im=imextendedmin(g2,10);   %  最小扩展变换,得到最小值附近的区域，此处的附近是相差**的区域
Lim=watershed(bwdist(im)); %watershed分水岭算法 Lim的值greater than or equal to 0，等于0是分水岭脊像素，bwdist计算二值图像的距离变换（求集水盆地到分水岭的距离）  
em=Lim==10;  
g3=imimposemin(g2,im|em);  %  强制最小，在梯度图上标出im和em，im是集水盆地的中心，em是分水岭
g4=watershed(g3);  
figure;  
imshow(g4);  
g5=I;  
g5(g4==0)=255;  
figure;  
imshow(g5);  