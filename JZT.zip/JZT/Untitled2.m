clear;clc;close all;
I=imread('12.jpg');
Ir0=I(:,:,1);% R通道
Ig0=I(:,:,2);% G通道
Ib0=I(:,:,3);% B通道
H=fspecial('gaussian',3,3);% 高斯模板

% 高层和中层操作一样
% R通道两次 卷积-下采样
Ir1=double(Ir0);%R通道底层
% 卷积
Ir2=filter2(H,Ir1,'same');
% 下采样
Ir2=imresize(Ir2,1/2);% R通道中层
% 卷积
Ir3=filter2(H,Ir2,'same');
% 下采样
Ir3=imresize(Ir3,1/2);% R通道高层

%G通道两次 卷积-下采样
Ig1=double(Ig0);% G通道底层
% 卷积
Ig2=filter2(H,Ig1,'same');
% 下采样
Ig2=imresize(Ig2,1/2);% G通道中层
% 卷积
Ig3=filter2(H,Ig2,'same');
% 下采样
Ig3=imresize(Ig3,1/2);% G通道高层

%B通道两次 卷积-下采样
Ib1=double(Ib0);% B通道底层
% 卷积
Ib2=filter2(H,Ib1,'same');
% 下采样
Ib2=imresize(Ib2,1/2);% B通道中层
% 卷积
Ib3=filter2(H,Ib2,'same');
% 下采样
Ib3=imresize(Ib3,1/2);% B通道高层

%合并三通道
I1(:,:,1)=Ir1;I1(:,:,2)=Ig1;I1(:,:,3)=Ib1;
I2(:,:,1)=Ir2;I2(:,:,2)=Ig2;I2(:,:,3)=Ib2;
I3(:,:,1)=Ir3;I3(:,:,2)=Ig3;I3(:,:,3)=Ib3;

% 展示结果
figure,imshow(uint8(I1));
title('底层');
figure,imshow(uint8(I2));
title('中层');
figure,imshow(uint8(I3));
title('高层');


I = uint8(I1);
figure;subplot(221);imshow(I);title('原图')
subplot(222);imhist(I);axis([0 225 0 1500]);title('原图的灰度直方图')
II=I;
for i = 1:size(I,1)
for j = 1:size(I,2)
if II(i,j)>=135
II(i,j)=255;
else
II(i,j)=0;
end
end
end
subplot(223);imshow(II);title('for循环实现的二值化')
III=im2bw(I,135/255);
subplot(224);imshow(III);title('im2bw实现的二值化')
