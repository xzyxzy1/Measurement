close all,clear all,clc;
I=imread('12.jpg');
row=size(I,1);
column=size(I,2);%2→dimision
N=zeros(1,256);%zeros(256)生成256x256矩阵
for i=1:row
    for j=1:column
        k=I(i,j);
        N(k+1)=N(k+1)+1;%记录每个灰度值的像素数
    end
end
figure;
subplot(121);imshow(I);%subplot将窗口分为1x2两个窗口，现在在第一个小窗口绘图
subplot(1,2,2);bar(N);%subplot(122)=subplot(1,2,2)
%bar函数绘制直方图，为N中每一行的每一个元素绘制一个条
axis tight;%设置坐标轴
